package com.hoda.scripts.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Map;

/** Durable, local checkpoint for user-started background runs. Stores action definitions and JSON-safe runtime values. */
public final class RunCheckpointStore {
    private static final String PREFS = "hoda_run_checkpoint";
    private static final String KEY = "pending_session";
    private RunCheckpointStore() {}

    public static synchronized void save(Context context, String name, JSONArray actions, int nextIndex, Map<String,Object> variables) {
        try {
            JSONObject state = new JSONObject();
            state.put("version", 1);
            state.put("name", name == null ? "Hoda Scripts" : name);
            state.put("actions", actions == null ? new JSONArray() : new JSONArray(actions.toString()));
            state.put("next_index", Math.max(0, nextIndex));
            state.put("saved_at", System.currentTimeMillis());
            JSONObject vars = new JSONObject();
            if (variables != null) for (Map.Entry<String,Object> entry : variables.entrySet()) {
                Object value = entry.getValue();
                if (value == null || value instanceof String || value instanceof Number || value instanceof Boolean || value instanceof JSONObject || value instanceof JSONArray) vars.put(entry.getKey(), value);
                else vars.put(entry.getKey(), String.valueOf(value));
            }
            state.put("variables", vars);
            SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY, state.toString()).commit();
        } catch (Exception ignored) { }
    }

    public static synchronized JSONObject get(Context context) {
        try {
            String raw = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "");
            if (raw == null || raw.isEmpty()) return null;
            JSONObject state = new JSONObject(raw);
            if (state.optInt("version", 0) != 1 || state.optJSONArray("actions") == null) return null;
            return state;
        } catch (Exception e) { return null; }
    }

    public static synchronized boolean hasPending(Context context) { return get(context) != null; }
    public static synchronized void clear(Context context) { context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).commit(); }
}
