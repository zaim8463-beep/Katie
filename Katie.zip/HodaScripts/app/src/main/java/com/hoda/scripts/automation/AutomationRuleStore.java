package com.hoda.scripts.automation;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Local, durable automation rules. A rule references a shortcut in the user's library. */
public final class AutomationRuleStore {
    private static final String PREFS="automation_rules_v1";
    private static final String KEY="rules";
    private AutomationRuleStore(){}
    public static synchronized List<JSONObject> all(Context c){
        List<JSONObject> out=new ArrayList<>();
        try{JSONArray a=new JSONArray(prefs(c).getString(KEY,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(new JSONObject(o.toString()));}}catch(Exception ignored){}
        return out;
    }
    public static synchronized void put(Context c,JSONObject rule){
        List<JSONObject> rules=all(c);String id=rule.optString("id","");boolean replaced=false;
        for(int i=0;i<rules.size();i++)if(rules.get(i).optString("id").equals(id)){rules.set(i,rule);replaced=true;break;}
        if(!replaced)rules.add(rule);save(c,rules);
    }
    public static synchronized void remove(Context c,String id){List<JSONObject> rules=all(c);for(int i=rules.size()-1;i>=0;i--)if(rules.get(i).optString("id").equals(id))rules.remove(i);save(c,rules);}
    private static void save(Context c,List<JSONObject> rules){JSONArray a=new JSONArray();for(JSONObject o:rules)a.put(o);prefs(c).edit().putString(KEY,a.toString()).apply();}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
}
