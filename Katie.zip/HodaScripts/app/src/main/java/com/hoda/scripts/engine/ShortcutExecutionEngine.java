package com.hoda.scripts.engine;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.widget.EditText;
import android.widget.Toast;

import com.hoda.scripts.model.Shortcut;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Executes a saved shortcut. Structured blocks use JSON configuration in their action "value". */
public final class ShortcutExecutionEngine {
    public interface Listener {
        void onStarted(String shortcutName);
        void onProgress(int completed, int total, String actionTitle);
        void onFinished(Map<String,Object> variables);
        void onError(String actionTitle, String message);
        default void onActionEvent(String actionTitle, String actionType, String status, long durationMs, String error) { }
        default void onPauseChanged(boolean paused) { }
        default void onCheckpoint(int nextTopLevelAction, Map<String,Object> variables) { }
    }

    private final Activity activity;
    private final Context context;
    private final Shortcut shortcut;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Map<String,Object> variables = new HashMap<>();
    private volatile boolean cancelled;
    private volatile boolean paused;
    private volatile String currentActionTitle = "";
    private volatile String currentActionType = "";
    private volatile long currentActionStartedAt;
    private volatile boolean currentActionEventRecorded;
    private int completed;
    private final int total;
    public static final int REQUEST_FILE_PICKER=8417;
    private Runnable pendingFileContinuation; private String pendingFileMode;
    private Runnable pausedContinuation;
    private int resumeTopLevelIndex;

    public ShortcutExecutionEngine(Activity activity, Shortcut shortcut, Listener listener) { this((Context)activity, shortcut, listener); }
    public ShortcutExecutionEngine(Context context, Shortcut shortcut, Listener listener) {
        this.context=context.getApplicationContext(); this.activity=context instanceof Activity?(Activity)context:null; this.shortcut=shortcut; this.listener=listener; this.total=countEnabled(shortcut.actions);
    }
    private Activity requireActivity(){if(activity==null)throw new IllegalStateException("This action needs the app screen and cannot run in background");return activity;}
    private void launch(Intent intent){if(!(context instanceof Activity))intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(intent);}

    /** Restores only the last completed top-level action boundary. The current action may be replayed after a crash. */
    public void restoreCheckpoint(int nextTopLevelAction, JSONObject savedVariables) {
        resumeTopLevelIndex = Math.max(0, Math.min(shortcut.actions.length(), nextTopLevelAction));
        if (savedVariables == null) return;
        java.util.Iterator<String> keys = savedVariables.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = savedVariables.opt(key);
            if (value != JSONObject.NULL) variables.put(key, value);
        }
    }

    public void start() {
        listener.onStarted(shortcut.name);
        runSequence(shortcut.actions, resumeTopLevelIndex, () -> listener.onFinished(new HashMap<>(variables)));
    }
    public void cancel() { cancelled=true; paused=false; io.shutdownNow(); pendingFileContinuation=null; }
    /** Pause takes effect at the next action boundary; an in-flight system/network call is not forcibly suspended. */
    public void pause() { if(!cancelled && !paused){paused=true;listener.onPauseChanged(true);} }
    public void resume() { if(!cancelled && paused){paused=false;listener.onPauseChanged(false);Runnable continuation=pausedContinuation;pausedContinuation=null;if(continuation!=null)main.post(continuation);} }
    public boolean isPaused() { return paused; }
    public void onActivityResult(int requestCode,int resultCode,Intent data) {
        if(requestCode!=REQUEST_FILE_PICKER||pendingFileContinuation==null)return;
        Runnable continuation=pendingFileContinuation;String mode=pendingFileMode;pendingFileContinuation=null;pendingFileMode=null;
        if(resultCode!=Activity.RESULT_OK||data==null||data.getData()==null){fail("File picker","No file was selected");return;}
        Uri uri=data.getData();try{int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);context.getContentResolver().takePersistableUriPermission(uri,flags);}catch(Exception ignored){}
        try {
            if("read".equals(mode)){try(InputStream in=context.getContentResolver().openInputStream(uri)){variables.put("result",readAll(in));}}
            else if("write".equals(mode)){try(OutputStream out=context.getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IllegalStateException("Cannot open destination");out.write(String.valueOf(variables.getOrDefault("result","")).getBytes(StandardCharsets.UTF_8));}variables.put("result",uri.toString());}
            else {variables.put("result",uri.toString());variables.put("file_uri",uri.toString());variables.put("file_name",displayName(uri));variables.put("file_mime",context.getContentResolver().getType(uri));}
            continuation.run();
        }catch(Exception e){fail("File action",e.getMessage());}
    }
    private String displayName(Uri uri){try(Cursor c=context.getContentResolver().query(uri,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return uri.getLastPathSegment()==null?"Selected file":uri.getLastPathSegment();}
    private void launchPicker(String mode,String mime,Runnable next){requireActivity();pendingFileContinuation=next;pendingFileMode=mode;Intent intent;if("write".equals(mode)){intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime);intent.putExtra(Intent.EXTRA_TITLE,"Hoda-output.txt");}else{intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);}requireActivity().startActivityForResult(intent,REQUEST_FILE_PICKER);}
    private void persistVariable(String name,Object value){try{JSONObject all=new JSONObject(context.getSharedPreferences("hoda_runtime_variables",Context.MODE_PRIVATE).getString("values","{}"));all.put(name,value instanceof JSONObject||value instanceof JSONArray?value:String.valueOf(value));context.getSharedPreferences("hoda_runtime_variables",Context.MODE_PRIVATE).edit().putString("values",all.toString()).apply();}catch(Exception e){throw new IllegalStateException("Could not persist variable",e);}}
    private Object loadVariable(String name){try{Object v=new JSONObject(context.getSharedPreferences("hoda_runtime_variables",Context.MODE_PRIVATE).getString("values","{}")).opt(name);return v==JSONObject.NULL?null:v;}catch(Exception e){return null;}}

    private int countEnabled(JSONArray actions) {
        int n=0;
        for(int i=0;i<actions.length();i++) {
            JSONObject a=actions.optJSONObject(i); if(a==null||!a.optBoolean("enabled",true)) continue;
            n++;
            JSONObject cfg=parseConfig(a.optString("value",""));
            n+=countEnabled(cfg.optJSONArray("then")); n+=countEnabled(cfg.optJSONArray("else")); n+=countEnabled(cfg.optJSONArray("actions"));
            JSONArray options=cfg.optJSONArray("options"); if(options!=null)for(int j=0;j<options.length();j++){JSONObject option=options.optJSONObject(j);if(option!=null)n+=countEnabled(option.optJSONArray("actions"));}
        }
        return n;
    }

    private void runSequence(JSONArray actions, int index, Runnable done) {
        if(cancelled) return;
        if(paused) { pausedContinuation=()->runSequence(actions,index,done); return; }
        if(actions==null || index>=actions.length()) { done.run(); return; }
        JSONObject action=actions.optJSONObject(index);
        if(action==null || !action.optBoolean("enabled",true)) { runSequence(actions,index+1,done); return; }
        String type=action.optString("type",""), title=action.optString("title",type);
        final long actionStartedAt=System.currentTimeMillis(); final java.util.concurrent.atomic.AtomicBoolean actionEventRecorded=new java.util.concurrent.atomic.AtomicBoolean(false);
        currentActionTitle=title; currentActionType=type; currentActionStartedAt=actionStartedAt; currentActionEventRecorded=false;
        listener.onProgress(completed,total,title);
        try { execute(action, () -> { if(actionEventRecorded.compareAndSet(false,true))listener.onActionEvent(title,type,"success",Math.max(0,System.currentTimeMillis()-actionStartedAt),""); completed++; if(actions==shortcut.actions) listener.onCheckpoint(index+1,new HashMap<>(variables)); runSequence(actions,index+1,done); }); }
        catch(Exception e) { if(actionEventRecorded.compareAndSet(false,true)){listener.onActionEvent(title,type,"failed",Math.max(0,System.currentTimeMillis()-actionStartedAt),e.getMessage());currentActionEventRecorded=true;} fail(title,e.getMessage()); }
    }

    private void execute(JSONObject a, Runnable next) throws Exception {
        String type=a.optString("type"), raw=interpolate(a.optString("value",""));
        switch(type) {
            case "text": variables.put("result",raw); next.run(); return;
            case "wait": {
                long ms=parseLong(raw,1000); if(ms<0||ms>24L*60*60*1000) throw new IllegalArgumentException("Wait must be between 0 and 24 hours");
                main.postDelayed(()->{if(!cancelled)next.run();},ms); return;
            }
            case "set_variable": {
                String name=a.optString("name", ""); String value=raw;
                if(name.trim().isEmpty()) { int split=raw.indexOf('='); if(split>0){name=raw.substring(0,split).trim();value=raw.substring(split+1);} }
                if(name.trim().isEmpty()) name="value";
                variables.put(name, value); persistVariable(name,value); variables.put("result",value); next.run(); return;
            }
            case "get_variable": {
                String name=raw.trim(); Object value=variables.get(name); if(value==null)value=loadVariable(name); if(value==null) throw new IllegalArgumentException("Variable not found: "+name);
                variables.put("result",value); next.run(); return;
            }
            case "list": {
                JSONArray list=new JSONArray(); String[] parts=raw.split("\\r?\\n|,",-1); for(String p:parts) list.put(p.trim());
                variables.put("result",list); next.run(); return;
            }
            case "dictionary": {
                JSONObject object=new JSONObject(raw); variables.put("result",object); next.run(); return;
            }
            case "json_parse": {
                String s=raw.trim(); Object parsed=s.startsWith("[")?new JSONArray(s):new JSONObject(s); variables.put("result",parsed); next.run(); return;
            }
            case "json_stringify": {Object v=variables.getOrDefault(raw.trim(),variables.get("result"));variables.put("result",v instanceof JSONObject||v instanceof JSONArray?v.toString():String.valueOf(v));next.run();return;}
            case "list_count": {Object v=variables.getOrDefault(raw.trim(),variables.get("result"));variables.put("result",v instanceof JSONArray?((JSONArray)v).length():v instanceof String?((String)v).length():0);next.run();return;}
            case "list_get": {JSONObject c=parseConfig(a.optString("value",""));Object v=variables.getOrDefault(c.optString("variable","result"),variables.get("result"));int i=c.optInt("index",0);if(!(v instanceof JSONArray)||i<0||i>=((JSONArray)v).length())throw new IllegalArgumentException("List index is out of range");variables.put("result",((JSONArray)v).opt(i));next.run();return;}
            case "list_append": {JSONObject c=parseConfig(a.optString("value",""));String n=c.optString("variable","result");Object v=variables.get(n);JSONArray list=v instanceof JSONArray?(JSONArray)v:new JSONArray();list.put(interpolate(c.optString("item","")));variables.put(n,list);variables.put("result",list);next.run();return;}
            case "if": {
                JSONObject c=parseConfigStrict(a.optString("value","")); boolean condition=evaluate(c);
                runSequence(c.optJSONArray(condition?"then":"else"),0,next); return;
            }
            case "repeat": {
                JSONObject c=parseConfigStrict(a.optString("value","")); int count=(int)Math.max(0,Math.min(1000,c.optInt("count",1)));
                repeat(c.optJSONArray("actions"),0,count,next); return;
            }
            case "repeat_each": {
                JSONObject c=parseConfigStrict(a.optString("value","")); JSONArray items=c.optJSONArray("items");
                if(items==null) { Object src=variables.get(c.optString("variable","result")); if(src instanceof JSONArray)items=(JSONArray)src; }
                if(items==null) throw new IllegalArgumentException("repeat_each needs an items array or a list variable");
                repeatEach(c.optJSONArray("actions"),items,0,next); return;
            }
            case "choose_menu": {
                JSONObject c=parseConfigStrict(a.optString("value","")); JSONArray options=c.optJSONArray("options"); if(options==null||options.length()==0)throw new IllegalArgumentException("Menu needs an options array");
                String[] labels=new String[options.length()]; for(int i=0;i<options.length();i++)labels[i]=options.optJSONObject(i)==null?options.optString(i):options.optJSONObject(i).optString("title","Option "+(i+1));
                new AlertDialog.Builder(requireActivity()).setTitle(c.optString("title","Choose an option")).setItems(labels,(d,w)->{
                    JSONObject selected=options.optJSONObject(w); JSONArray branch=selected==null?null:selected.optJSONArray("actions");
                    if(branch==null) { variables.put("result",labels[w]); next.run(); } else runSequence(branch,0,next);
                }).setOnCancelListener(d->fail("Choose from Menu","Menu cancelled")).show(); return;
            }
            case "ask_input": {
                EditText input=new EditText(requireActivity()); input.setHint(a.optString("hint","Enter a value"));
                new AlertDialog.Builder(requireActivity()).setTitle(raw.isEmpty()?a.optString("prompt","Ask for Input"):raw).setView(input)
                    .setNegativeButton("Cancel",(d,w)->fail("Ask for Input","Input cancelled"))
                    .setPositiveButton("OK",(d,w)->{variables.put("result",input.getText().toString());next.run();}).show(); return;
            }
            case "clipboard": {
                ClipboardManager cm=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("Hoda Scripts",raw)); variables.put("result",raw); next.run(); return;
            }
            case "get_clipboard": {
                ClipboardManager cm=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
                if(cm==null||!cm.hasPrimaryClip()||cm.getPrimaryClip().getItemCount()==0)throw new IllegalStateException("Clipboard is empty or unavailable");
                CharSequence text=cm.getPrimaryClip().getItemAt(0).coerceToText(context); variables.put("result",text==null?"":text.toString()); next.run(); return;
            }
            case "url": launch(new Intent(Intent.ACTION_VIEW,Uri.parse(raw))); variables.put("result",raw); next.run(); return;
            case "accessibility_global": {
                String command=raw.trim().toLowerCase(java.util.Locale.ROOT);
                if(!com.hoda.scripts.accessibility.HodaAccessibilityService.isConnected())
                    throw new SecurityException("Enable Hoda Scripts Accessibility in Android Settings first");
                if(!com.hoda.scripts.accessibility.HodaAccessibilityService.perform(command))
                    throw new IllegalArgumentException("Unsupported action or accessibility service is unavailable: "+command);
                variables.put("result",command); next.run(); return;
            }
            case "accessibility_tap": {
                if(!com.hoda.scripts.accessibility.HodaAccessibilityService.isConnected())
                    throw new SecurityException("Enable Hoda Scripts Accessibility in Android Settings first");
                JSONObject point=new JSONObject(raw);
                float x=(float)point.getDouble("x"), y=(float)point.getDouble("y");
                if(!com.hoda.scripts.accessibility.HodaAccessibilityService.tap(x,y))
                    throw new IllegalStateException("Could not dispatch tap gesture");
                variables.put("result","tap:"+x+","+y); next.run(); return;
            }
            case "open_app": {
                String pkg=raw.trim(); Intent launch=context.getPackageManager().getLaunchIntentForPackage(pkg);
                if(launch==null)throw new IllegalArgumentException("No launchable app for package: "+pkg);
                launch(launch); variables.put("result",pkg); next.run(); return;
            }
            case "plugin_intent": {
                JSONObject config=parseConfig(raw);String mode=config.optString("mode","view").trim().toLowerCase(java.util.Locale.ROOT);
                Intent external;
                if("share".equals(mode)){
                    external=new Intent(Intent.ACTION_SEND);external.setType(config.optString("mime","text/plain"));external.putExtra(Intent.EXTRA_TEXT,interpolate(config.optString("text","")));
                    launch(Intent.createChooser(external,"Share with"));variables.put("result","shared");next.run();return;
                }
                if(!"view".equals(mode))throw new IllegalArgumentException("Supported integration modes are view and share");
                String target=interpolate(config.optString("uri",""));Uri uri=Uri.parse(target);String scheme=uri.getScheme();
                if(scheme==null||!(scheme.equalsIgnoreCase("https")||scheme.equalsIgnoreCase("http")||scheme.equalsIgnoreCase("mailto")||scheme.equalsIgnoreCase("tel")||scheme.equalsIgnoreCase("geo")))
                    throw new IllegalArgumentException("Only http, https, mailto, tel and geo links are supported");
                external=new Intent(Intent.ACTION_VIEW,uri);String pkg=config.optString("package","").trim();if(!pkg.isEmpty())external.setPackage(pkg);
                launch(external);variables.put("result",target);next.run();return;
            }
            case "notification": showNotification(a.optString("title","Hoda Scripts"),raw.isEmpty()?shortcut.name:raw); next.run(); return;
            case "vibrate": {
                Vibrator v=(Vibrator)context.getSystemService(Context.VIBRATOR_SERVICE); if(v!=null&&v.hasVibrator()) {
                    long ms=Math.max(1,Math.min(3000,parseLong(raw,250)));
                    if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE));else v.vibrate(ms);
                } next.run(); return;
            }
            case "brightness": {
                if(!Settings.System.canWrite(context)) { launch(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+context.getPackageName()))); throw new SecurityException("Allow Modify system settings, then run the shortcut again"); }
                int n=(int)Math.max(1,Math.min(255,parseLong(raw,128))); Settings.System.putInt(context.getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,n); next.run(); return;
            }
            case "share": {
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_TEXT,raw); launch(Intent.createChooser(send,"Share")); variables.put("result",raw); next.run(); return;
            }
            case "http_get": case "http_post": {
                JSONObject c=parseConfig(a.optString("value","")); String url=interpolate(c.optString("url",raw)); String method=type.equals("http_get")?"GET":"POST"; String body=interpolate(c.optString("body",""));
                final int maxRetries=Math.max(0,Math.min(3,c.optInt("retryCount",0)));
                final long retryDelay=Math.max(250,Math.min(5000,c.optLong("retryDelayMs",750)));
                io.execute(()->{
                    String finalResponse=null;int finalStatus=-1;Exception lastError=null;
                    for(int attempt=0;attempt<=maxRetries&&!cancelled;attempt++){
                        HttpURLConnection conn=null;
                        try{
                            conn=(HttpURLConnection)new URL(url).openConnection();conn.setRequestMethod(method);conn.setConnectTimeout(15000);conn.setReadTimeout(20000);conn.setRequestProperty("Accept","application/json, text/plain, */*");
                            JSONObject headers=c.optJSONObject("headers");if(headers!=null){Iterator<String> keys=headers.keys();while(keys.hasNext()){String key=keys.next();conn.setRequestProperty(key,interpolate(String.valueOf(headers.opt(key))));}}
                            if(method.equals("POST")){conn.setDoOutput(true);conn.setRequestProperty("Content-Type",c.optString("contentType","application/json; charset=utf-8"));try(OutputStream os=conn.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}}
                            int code=conn.getResponseCode();
                            if((code==429||code>=500)&&attempt<maxRetries){conn.disconnect();conn=null;Thread.sleep(retryDelay*(attempt+1));continue;}
                            InputStream stream=code>=400?conn.getErrorStream():conn.getInputStream();finalResponse=readAll(stream);finalStatus=code;lastError=null;break;
                        }catch(Exception error){lastError=error;if(attempt<maxRetries&&!cancelled){try{Thread.sleep(retryDelay*(attempt+1));}catch(InterruptedException interrupted){Thread.currentThread().interrupt();lastError=interrupted;break;}}}
                        finally{if(conn!=null)conn.disconnect();}
                    }
                    final String result=finalResponse;final int status=finalStatus;final Exception error=lastError;
                    main.post(()->{if(cancelled)return;if(error!=null){fail(type,"Request failed after retries: "+error.getMessage());return;}variables.put("result",result==null?"":result);variables.put("http_status",status);next.run();});
                }); return;
            }
            case "file_read": launchPicker("read",a.optString("mime","*/*"),next); return;
            case "file_write": launchPicker("write",a.optString("mime","text/plain"),next); return;
            case "pick_image": launchPicker("pick","image/*",next); return;
            case "pick_video": launchPicker("pick","video/*",next); return;
            case "pick_audio": launchPicker("pick","audio/*",next); return;
            case "pick_pdf": launchPicker("pick","application/pdf",next); return;
            case "file_info": {String u=raw.isEmpty()?String.valueOf(variables.getOrDefault("file_uri","")):raw;Uri uri=Uri.parse(u);variables.put("result",new JSONObject().put("uri",u).put("name",displayName(uri)).put("mime",context.getContentResolver().getType(uri)).toString());next.run();return;}
            case "open_file": {String u=raw.isEmpty()?String.valueOf(variables.getOrDefault("file_uri","")):raw;Uri uri=Uri.parse(u);Intent view=new Intent(Intent.ACTION_VIEW);view.setDataAndType(uri,context.getContentResolver().getType(uri));view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);launch(Intent.createChooser(view,"Open file"));variables.put("result",u);next.run();return;}
            case "share_file": {String u=raw.isEmpty()?String.valueOf(variables.getOrDefault("file_uri","")):raw;Uri uri=Uri.parse(u);Intent send=new Intent(Intent.ACTION_SEND);send.setType(context.getContentResolver().getType(uri)==null?"*/*":context.getContentResolver().getType(uri));send.putExtra(Intent.EXTRA_STREAM,uri);send.setClipData(ClipData.newUri(context.getContentResolver(),"Hoda file",uri));send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);launch(Intent.createChooser(send,"Share file"));variables.put("result",u);next.run();return;}
            default: throw new UnsupportedOperationException("Action is not executable yet: "+type);
        }
    }

    private void repeat(JSONArray body,int index,int count,Runnable done) {
        if(cancelled)return; if(index>=count){done.run();return;}
        variables.put("repeat_index",index+1); runSequence(body,0,()->main.post(()->repeat(body,index+1,count,done)));
    }
    private void repeatEach(JSONArray body,JSONArray items,int index,Runnable done) {
        if(cancelled)return; if(index>=items.length()){done.run();return;}
        Object item=items.opt(index);variables.put("item",item);variables.put("repeat_index",index+1);
        runSequence(body,0,()->main.post(()->repeatEach(body,items,index+1,done)));
    }
    private boolean evaluate(JSONObject c) {
        JSONArray all=c.optJSONArray("all"); if(all!=null){for(int i=0;i<all.length();i++){JSONObject item=all.optJSONObject(i);if(item==null||!evaluate(item))return false;}return true;}
        JSONArray any=c.optJSONArray("any"); if(any!=null){for(int i=0;i<any.length();i++){JSONObject item=any.optJSONObject(i);if(item!=null&&evaluate(item))return true;}return false;}
        String left=String.valueOf(resolve(c.opt("left"))), right=String.valueOf(resolve(c.opt("right"))), op=c.optString("operator","equals");
        switch(op){case"not_equals":return !left.equals(right);case"contains":return left.contains(right);case"starts_with":return left.startsWith(right);case"ends_with":return left.endsWith(right);case"greater_than":return number(left)>number(right);case"greater_or_equal":return number(left)>=number(right);case"less_than":return number(left)<number(right);case"less_or_equal":return number(left)<=number(right);case"is_empty":return left.isEmpty();case"is_not_empty":return !left.isEmpty();default:return left.equals(right);}
    }
    private Object resolve(Object v){if(v==null)return "";if(v instanceof String){String s=(String)v;if(s.startsWith("$"))return variables.getOrDefault(s.substring(1),"");return s;}return v;}
    private double number(String s){try{return Double.parseDouble(s);}catch(Exception e){return 0;}}
    private String interpolate(String input) {
        if(input==null)return ""; String out=input;
        for(Map.Entry<String,Object> e:variables.entrySet())out=out.replace("${"+e.getKey()+"}",String.valueOf(e.getValue())).replace("$"+e.getKey(),String.valueOf(e.getValue()));
        return out;
    }
    private JSONObject parseConfig(String value) { try{return new JSONObject(value);}catch(Exception e){return new JSONObject();} }
    private JSONObject parseConfigStrict(String value) throws JSONException {
        if(value==null||!value.trim().startsWith("{")) throw new IllegalArgumentException("This action needs a JSON object configuration. Use the example shown in the field hint.");
        return new JSONObject(value);
    }
    private long parseLong(String s,long fallback){try{return Long.parseLong(s.trim());}catch(Exception e){return fallback;}}
    private String readAll(InputStream in)throws Exception{if(in==null)return "";StringBuilder b=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)b.append(line).append('\n');}return b.toString().trim();}
    private void showNotification(String title,String body){
        String channel="hoda_action_results";NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){nm.createNotificationChannel(new NotificationChannel(channel,"Hoda action results",NotificationManager.IMPORTANCE_DEFAULT));}
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(context,channel):new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true);
        try{nm.notify((int)(System.currentTimeMillis()%Integer.MAX_VALUE),b.build());}catch(SecurityException e){Toast.makeText(context,body,Toast.LENGTH_LONG).show();}
    }
    private void fail(String title,String message){if(!cancelled && currentActionStartedAt>0 && !currentActionEventRecorded){listener.onActionEvent(currentActionTitle,currentActionType,"failed",Math.max(0,System.currentTimeMillis()-currentActionStartedAt),message);currentActionEventRecorded=true;}cancelled=true;paused=false;pausedContinuation=null;listener.onError(title,message==null?"Unknown error":message);}
}
