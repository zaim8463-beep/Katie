package com.hoda.scripts.data;

import android.content.Context;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Comparator;

/** Keeps a small rotating set of private, local library snapshots. */
public final class LocalBackupManager {
    private static final String PREFIX = "hoda-library-";
    private static final int KEEP = 5;
    private static final long MAX_BYTES = 5L * 1024L * 1024L;
    private LocalBackupManager() {}

    public static synchronized File createSnapshot(Context context, JSONObject backup) throws Exception {
        byte[] bytes = backup.toString(2).getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_BYTES) throw new IllegalArgumentException("Backup exceeds 5 MB");
        File dir = new File(context.getFilesDir(), "library_backups");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create backup directory");
        File target = new File(dir, PREFIX + System.currentTimeMillis() + ".json");
        File temp = new File(dir, target.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(temp)) { out.write(bytes); out.getFD().sync(); }
        if (!temp.renameTo(target)) { temp.delete(); throw new IllegalStateException("Cannot finalize local backup"); }
        prune(dir);
        context.getSharedPreferences("hoda_local_backup", Context.MODE_PRIVATE).edit()
                .putString("last_hash", sha256(bytes)).apply();
        return target;
    }

    public static synchronized boolean createIfChanged(Context context, JSONObject backup) {
        try {
            byte[] bytes = backup.toString(2).getBytes(StandardCharsets.UTF_8);
            String hash = sha256(bytes);
            String previous = context.getSharedPreferences("hoda_local_backup", Context.MODE_PRIVATE).getString("last_hash", "");
            if (hash.equals(previous) && latest(context) != null) return false;
            createSnapshot(context, backup);
            return true;
        } catch (Exception ignored) { return false; }
    }

    public static synchronized File latest(Context context) {
        File dir = new File(context.getFilesDir(), "library_backups");
        File[] files = dir.listFiles((d, name) -> name.startsWith(PREFIX) && name.endsWith(".json"));
        if (files == null || files.length == 0) return null;
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        return files[0];
    }

    public static synchronized int count(Context context) {
        File dir = new File(context.getFilesDir(), "library_backups");
        File[] files = dir.listFiles((d, name) -> name.startsWith(PREFIX) && name.endsWith(".json"));
        return files == null ? 0 : files.length;
    }

    private static void prune(File dir) {
        File[] files = dir.listFiles((d, name) -> name.startsWith(PREFIX) && name.endsWith(".json"));
        if (files == null) return;
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        for (int i = KEEP; i < files.length; i++) files[i].delete();
    }

    private static String sha256(byte[] data) throws Exception {
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder out = new StringBuilder();
        for (byte b : digest) out.append(String.format(java.util.Locale.ROOT, "%02x", b));
        return out.toString();
    }
}
