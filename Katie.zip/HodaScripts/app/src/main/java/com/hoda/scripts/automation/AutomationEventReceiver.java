package com.hoda.scripts.automation;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import org.json.JSONObject;

/** Receives selected system events. Android/OEM background-start restrictions still apply. */
public class AutomationEventReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null)return;String event=intent.getAction();String key=null;
        if(Intent.ACTION_POWER_CONNECTED.equals(event))key="power_connected";
        else if(Intent.ACTION_POWER_DISCONNECTED.equals(event))key="power_disconnected";
        else if(Intent.ACTION_BATTERY_LOW.equals(event))key="battery_low";
        else if(Intent.ACTION_BATTERY_OKAY.equals(event))key="battery_okay";
        else if(BluetoothAdapter.ACTION_STATE_CHANGED.equals(event)){
            int state=intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,BluetoothAdapter.ERROR);
            if(state==BluetoothAdapter.STATE_ON)key="bluetooth_on";else if(state==BluetoothAdapter.STATE_OFF)key="bluetooth_off";
        } else if(WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(event)){
            android.net.NetworkInfo info=intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
            if(info!=null&&info.isConnected())key="wifi_connected";else if(info!=null&&info.getState()==android.net.NetworkInfo.State.DISCONNECTED)key="wifi_disconnected";
        }
        if(key==null)return;
        for(JSONObject rule:AutomationRuleStore.all(context))if(rule.optBoolean("enabled",true)&&key.equals(rule.optString("trigger")))AutomationRunner.run(context,rule.optLong("shortcut_id"));
    }
}
