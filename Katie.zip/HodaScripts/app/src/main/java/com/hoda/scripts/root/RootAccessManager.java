package com.hoda.scripts.root;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Optional, user-confirmed Magisk/SU integration. Changes are scoped to this app package. */
public final class RootAccessManager {
    private RootAccessManager() {}

    public static final class Result {
        public final boolean rootGranted;
        public final boolean success;
        public final int successfulCommands;
        public final int failedCommands;
        public final List<String> output;
        Result(boolean granted, boolean ok, int succeeded, int failed, List<String> lines) {
            rootGranted = granted; success = ok; successfulCommands = succeeded;
            failedCommands = failed; output = lines;
        }
    }

    /** Applies only reversible background exemptions for Hoda Scripts, after Android's SU prompt. */
    public static Result applyBackgroundExemptions(Context context) {
        String pkg = context.getPackageName();
        String[] commands = new String[] {
            "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow",
            "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow",
            "dumpsys deviceidle whitelist +" + pkg
        };
        return runAsRoot(commands);
    }

    /** Reverts the app-ops and Doze whitelist changes made by applyBackgroundExemptions. */
    public static Result revokeBackgroundExemptions(Context context) {
        String pkg = context.getPackageName();
        String[] commands = new String[] {
            "cmd appops set " + pkg + " RUN_IN_BACKGROUND default",
            "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND default",
            "dumpsys deviceidle whitelist -" + pkg
        };
        return runAsRoot(commands);
    }

    public static Result checkRoot() { return runAsRoot(new String[] {"id"}); }

    private static Result runAsRoot(String[] commands) {
        List<String> lines = new ArrayList<>();
        Process process = null;
        boolean granted = false;
        int succeeded = 0, failed = 0;
        try {
            process = new ProcessBuilder("su").redirectErrorStream(true).start();
            OutputStream stdin = process.getOutputStream();
            stdin.write("id\n".getBytes(StandardCharsets.UTF_8));
            stdin.flush();
            // Root identity is checked before running any requested operation.
            for (int i = 0; i < commands.length; i++) {
                String marker = "HODA_CMD_" + i;
                String command = commands[i];
                stdin.write(("if " + command + "; then echo " + marker + "_OK; else echo " + marker + "_FAILED; fi\n").getBytes(StandardCharsets.UTF_8));
                stdin.flush();
            }
            stdin.write("exit\n".getBytes(StandardCharsets.UTF_8));
            stdin.flush();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    lines.add(line);
                    if (line.contains("uid=0") || line.contains("uid 0")) granted = true;
                    for (int i = 0; i < commands.length; i++) {
                        if (line.contains("HODA_CMD_" + i + "_OK")) succeeded++;
                        else if (line.contains("HODA_CMD_" + i + "_FAILED")) failed++;
                    }
                }
            }
            process.waitFor();
            if (!granted) lines.add("Root permission was not granted. No changes were applied.");
            if (granted && failed > 0) lines.add("Some commands were unavailable or rejected by this Android version.");
            boolean ok = granted && (commands.length == 0 || succeeded > 0) && failed == 0;
            return new Result(granted, ok, succeeded, failed, lines);
        } catch (Exception e) {
            lines.add(e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
            return new Result(granted, false, succeeded, failed + 1, lines);
        } finally {
            if (process != null) process.destroy();
        }
    }
}
