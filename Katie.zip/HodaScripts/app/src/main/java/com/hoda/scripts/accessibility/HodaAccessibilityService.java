package com.hoda.scripts.accessibility;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;

/** Optional, user-enabled accessibility bridge. It is never enabled programmatically. */
public final class HodaAccessibilityService extends AccessibilityService {
    private static volatile HodaAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* Event contents are intentionally not collected or stored. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if(instance==this)instance=null; super.onDestroy(); }
    public static boolean isConnected() { return instance!=null; }
    public static boolean perform(String action) {
        HodaAccessibilityService s=instance; if(s==null)return false;
        int id;
        switch(action) {
            case "back": id=GLOBAL_ACTION_BACK; break;
            case "home": id=GLOBAL_ACTION_HOME; break;
            case "recents": id=GLOBAL_ACTION_RECENTS; break;
            case "notifications": id=GLOBAL_ACTION_NOTIFICATIONS; break;
            case "quick_settings": id=GLOBAL_ACTION_QUICK_SETTINGS; break;
            case "power_dialog": id=GLOBAL_ACTION_POWER_DIALOG; break;
            default: return false;
        }
        return s.performGlobalAction(id);
    }
    public static boolean tap(float x,float y) {
        HodaAccessibilityService s=instance;
        if(s==null || Build.VERSION.SDK_INT<24 || x<0 || y<0)return false;
        Path path=new Path(); path.moveTo(x,y);
        GestureDescription gesture=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path,0,80)).build();
        return s.dispatchGesture(gesture,null,null);
    }
}
