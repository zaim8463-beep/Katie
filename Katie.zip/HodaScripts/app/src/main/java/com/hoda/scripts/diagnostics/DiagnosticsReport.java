package com.hoda.scripts.diagnostics;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import com.hoda.scripts.accessibility.HodaAccessibilityService;
import com.hoda.scripts.automation.AutomationRuleStore;
import com.hoda.scripts.data.RunHistoryStore;
import com.hoda.scripts.data.ShortcutStore;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/** Builds a privacy-conscious support report. It never includes shortcut names, inputs, outputs, or file contents. */
public final class DiagnosticsReport {
    private DiagnosticsReport() {}

    public static String build(Context context) {
        Context app = context.getApplicationContext();
        StringBuilder out = new StringBuilder();
        out.append("Hoda Scripts diagnostics\n");
        out.append("Generated: ").append(new java.util.Date()).append("\n\n");
        out.append("App version: ").append(version(app)).append("\n");
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Device manufacturer: ").append(safe(Build.MANUFACTURER)).append("\n");
        out.append("Device model: ").append(safe(Build.MODEL)).append("\n\n");

        boolean batteryExempt = false;
        try {
            PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
            batteryExempt = Build.VERSION.SDK_INT >= 23 && pm != null && pm.isIgnoringBatteryOptimizations(app.getPackageName());
        } catch (Exception ignored) {}
        out.append("Battery optimization exemption: ").append(batteryExempt ? "Granted" : "Not granted / unavailable").append("\n");
        out.append("Accessibility service: ").append(isAccessibilityEnabled(app) ? "Enabled in system settings" : "Not enabled").append("\n");
        out.append("Accessibility connection: ").append(HodaAccessibilityService.isConnected() ? "Connected" : "Not connected").append("\n");
        out.append("Notifications: ").append(notificationsEnabled(app) ? "Enabled" : "Disabled / unavailable").append("\n");
        out.append("Speech recognition: ").append(hasSpeechRecognizer(app) ? "Available" : "No handler found").append("\n\n");

        int shortcuts = 0;
        try { shortcuts = new ShortcutStore(app).all().size(); } catch (Exception ignored) {}
        List<JSONObject> rules = AutomationRuleStore.all(app);
        int enabledRules = 0;
        for (JSONObject rule : rules) if (rule.optBoolean("enabled", true)) enabledRules++;
        JSONArray history = RunHistoryStore.get(app);
        int success = 0, failed = 0;
        for (int i = 0; i < history.length(); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item == null) continue;
            if (item.optBoolean("success")) success++; else failed++;
        }
        out.append("Saved shortcuts count: ").append(shortcuts).append("\n");
        out.append("Automation rules: ").append(rules.size()).append(" total, ").append(enabledRules).append(" enabled\n");
        out.append("Recent run history: ").append(history.length()).append(" entries (up to 100)\n");
        out.append("Recent outcomes: ").append(success).append(" successful, ").append(failed).append(" failed\n\n");
        out.append("Privacy: This report excludes shortcut titles, action configurations, runtime variables, action inputs/outputs, file paths, and history details.\n");
        out.append("Note: Diagnostic status is informational and does not prove that Android will allow every background task.");
        return out.toString();
    }

    private static String version(Context c) {
        try {
            PackageInfo info = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            if (Build.VERSION.SDK_INT >= 28) return info.versionName + " (" + info.getLongVersionCode() + ")";
            return info.versionName + " (" + info.versionCode + ")";
        } catch (Exception e) { return "Unknown"; }
    }

    private static boolean notificationsEnabled(Context c) {
        try {
            if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false;
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm == null || nm.areNotificationsEnabled();
        } catch (Exception e) { return false; }
    }

    private static boolean hasSpeechRecognizer(Context c) {
        try {
            android.content.Intent intent = new android.content.Intent("android.speech.action.RECOGNIZE_SPEECH");
            return intent.resolveActivity(c.getPackageManager()) != null;
        } catch (Exception e) { return false; }
    }

    private static boolean isAccessibilityEnabled(Context c) {
        try {
            String enabled = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String target = new android.content.ComponentName(c, HodaAccessibilityService.class).flattenToString();
            for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        } catch (Exception ignored) {}
        return false;
    }

    private static String safe(String value) { return value == null ? "Unknown" : value.replace('\n', ' ').replace('\r', ' '); }
}
