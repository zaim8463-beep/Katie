package com.hoda.scripts.engine;

import com.hoda.scripts.model.Shortcut;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Static preflight checks; never executes actions or requests permissions. */
public final class ShortcutValidator {
    public static final class Issue {
        public final String path, message;
        public final boolean warning;
        Issue(String p, String m, boolean w) { path=p; message=m; warning=w; }
        @Override public String toString() { return (warning ? "Warning" : "Error") + " · " + path + " — " + message; }
    }
    private static final Set<String> KNOWN = new HashSet<>();
    static { for (ActionCatalog.Definition d : ActionCatalog.all()) KNOWN.add(d.id); }
    private ShortcutValidator() {}

    public static List<Issue> validate(Shortcut shortcut) {
        List<Issue> issues = new ArrayList<>();
        if (shortcut == null) { issues.add(new Issue("Shortcut", "Shortcut is missing", false)); return issues; }
        if (shortcut.name.trim().isEmpty()) issues.add(new Issue("Shortcut", "Name is empty", false));
        validateActions(shortcut.actions, "1", issues, 0);
        return issues;
    }

    public static List<Issue> validateLibrary(List<Shortcut> shortcuts) {
        List<Issue> all = new ArrayList<>();
        if (shortcuts == null) return all;
        for (Shortcut shortcut : shortcuts) {
            for (Issue issue : validate(shortcut)) all.add(new Issue(shortcut.name + " / " + issue.path, issue.message, issue.warning));
        }
        return all;
    }

    private static void validateActions(JSONArray actions, String prefix, List<Issue> out, int depth) {
        if (actions == null) return;
        if (depth > 12) { out.add(new Issue(prefix, "Nested blocks exceed the supported validation depth", false)); return; }
        for (int i=0; i<actions.length(); i++) {
            String path = prefix + "." + (i+1);
            JSONObject action = actions.optJSONObject(i);
            if (action == null) { out.add(new Issue(path, "Action entry is not an object", false)); continue; }
            if (!action.optBoolean("enabled", true)) continue;
            String type = action.optString("type", "").trim();
            if (type.isEmpty()) { out.add(new Issue(path, "Action type is missing", false)); continue; }
            if (!KNOWN.contains(type)) { out.add(new Issue(path, "Unknown action type: " + type, false)); continue; }
            String value = action.optString("value", "");
            if ("wait".equals(type)) {
                try { long ms=Long.parseLong(value.trim()); if(ms<0||ms>86400000L) throw new NumberFormatException(); }
                catch(Exception e) { out.add(new Issue(path, "Wait must be a number from 0 to 86400000 milliseconds", false)); }
            } else if ("if".equals(type) || "repeat".equals(type) || "repeat_each".equals(type)) {
                JSONObject cfg = object(value, path, out);
                if (cfg != null) {
                    if ("if".equals(type)) {
                        if (cfg.optString("operator", "").trim().isEmpty()) out.add(new Issue(path, "If block has no comparison operator", false));
                        validateActions(cfg.optJSONArray("then"), path+".then", out, depth+1);
                        validateActions(cfg.optJSONArray("else"), path+".else", out, depth+1);
                    } else {
                        if ("repeat".equals(type) && (cfg.optInt("count", -1)<0 || cfg.optInt("count", -1)>1000)) out.add(new Issue(path, "Repeat count must be from 0 to 1000", false));
                        if ("repeat_each".equals(type) && cfg.optJSONArray("items")==null && cfg.optString("variable", "").trim().isEmpty()) out.add(new Issue(path, "Repeat Each needs items or a list variable", false));
                        validateActions(cfg.optJSONArray("actions"), path+".actions", out, depth+1);
                    }
                }
            } else if ("dictionary".equals(type) || "json_parse".equals(type)) {
                if (!value.contains("$") && !value.trim().isEmpty()) {
                    try { if (value.trim().startsWith("[")) new JSONArray(value); else new JSONObject(value); }
                    catch (JSONException e) { out.add(new Issue(path, "JSON value cannot be parsed", false)); }
                }
            } else if ("http_get".equals(type) || "http_post".equals(type)) {
                JSONObject cfg;
                String url;
                if (value.trim().startsWith("{")) { cfg=object(value,path,out); url=cfg==null?"":cfg.optString("url",""); }
                else { cfg=new JSONObject(); url=value.trim(); }
                if (cfg != null) {
                    if (!url.isEmpty() && !url.contains("$") && !validHttpUrl(url)) out.add(new Issue(path, "URL must use http or https", false));
                    int retries=cfg.optInt("retryCount",0);
                    if(retries<0||retries>3) out.add(new Issue(path, "Retry count must be from 0 to 3", false));
                    if("http_post".equals(type)) out.add(new Issue(path, "POST may repeat a server-side operation when retries are enabled", true));
                }
            } else if ("plugin_intent".equals(type)) {
                JSONObject cfg = object(value, path, out);
                if (cfg != null && "view".equals(cfg.optString("mode", "view"))) {
                    String uri=cfg.optString("uri", "");
                    if(uri.isEmpty()) out.add(new Issue(path, "Integration URI is empty", false));
                    else if(!uri.contains("$") && !allowedScheme(uri)) out.add(new Issue(path, "Unsupported integration URI scheme", false));
                }
            } else if ("accessibility_tap".equals(type)) {
                JSONObject cfg=object(value,path,out);
                if(cfg!=null && (!cfg.has("x")||!cfg.has("y"))) out.add(new Issue(path,"Tap needs x and y coordinates",false));
                out.add(new Issue(path,"Requires the user to enable Hoda Accessibility in Android settings",true));
            } else if ("accessibility_global".equals(type)) {
                out.add(new Issue(path,"Requires the user to enable Hoda Accessibility in Android settings",true));
            } else if ("ask_input".equals(type) || "choose_menu".equals(type) || type.startsWith("pick_") || "file_read".equals(type) || "file_write".equals(type)) {
                out.add(new Issue(path,"Requires the app screen and cannot run unattended in the background",true));
            }
        }
    }

    private static JSONObject object(String value, String path, List<Issue> out) {
        try { return new JSONObject(value); }
        catch (Exception e) { out.add(new Issue(path, "Expected a JSON object in this action's configuration", false)); return null; }
    }
    private static boolean validHttpUrl(String value) { try { URI u=URI.create(value); return ("http".equalsIgnoreCase(u.getScheme())||"https".equalsIgnoreCase(u.getScheme()))&&u.getHost()!=null; } catch(Exception e){return false;} }
    private static boolean allowedScheme(String value) { try { String s=URI.create(value).getScheme(); return s!=null&&(s.equalsIgnoreCase("http")||s.equalsIgnoreCase("https")||s.equalsIgnoreCase("mailto")||s.equalsIgnoreCase("tel")||s.equalsIgnoreCase("geo")); } catch(Exception e){return false;} }
}
